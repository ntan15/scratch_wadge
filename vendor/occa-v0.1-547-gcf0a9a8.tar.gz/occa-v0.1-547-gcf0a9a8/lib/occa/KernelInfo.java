package occa;

public class KernelInfo {
  long handle;

  KernelInfo(){
    handle = 0;
  }
}