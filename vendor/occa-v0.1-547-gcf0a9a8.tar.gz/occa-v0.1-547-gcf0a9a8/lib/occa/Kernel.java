package occa;

public class Kernel {
}