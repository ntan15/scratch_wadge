package occa;

public class Stream {
}